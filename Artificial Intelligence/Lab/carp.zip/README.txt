This package contains:
    Project-CARP.pdf                      # This is the instruction to project requirement of CARP. 
    sample.dat                            # A sample describe the input and output
    CARPReportGradingRules.xlsx           #This is the grading rules for the CARP report
You should read it first
    CARP_samples/                         # Some CARP instance files
    CARP_format.txt                       # The format of the CARP instance file
    CARP.pdf                              # Introduction to CARP
